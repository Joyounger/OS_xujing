#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int value;
void main (int argc, char** argv)
{
	char buf[32];
	FILE* fd; 
	if(argc<2){
		printf("usage:test delay_parameter\n");
		exit(0);
	}
	sscanf(argv[1],"%d",&value);
		
	fd=fopen("/dev/trlight","r");
	if (fread(buf,1,32,fd)<=0)
		perror("error in fread\n");
	printf("current %s\n",buf);
	
	fclose(fd);
	fd=fopen("/dev/trlight","w");
	if (fwrite(&value,sizeof(value),1,fd)<=0)
		perror("error in write\n");
	printf("set value=%d\n",value);
	fclose(fd);

}
	
