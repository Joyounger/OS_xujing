/* define ioctls */
#define TRLIGHT_START	      0x1643	
#define TRLIGHT_STOP          0x1644
