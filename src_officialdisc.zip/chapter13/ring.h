#define R_SIGNATURE 0x860510
typedef struct{
	long signature;
	int *head;
	int *tail;
	int *end;
	int *begin;
	int buffer[64];
}ring_buf;

void ring_buf_init(ring_buf *round);
int ring_buf_read(ring_buf *round,int *buf);
int ring_buf_write(ring_buf *round,int val);

