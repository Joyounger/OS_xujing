#include <unistd.h>
#include <linux/kernel.h>
#include "ring.h"
int  tag=0;
int * psudo_head=NULL;

void ring_buf_init(ring_buf *round)
{
        round->signature=R_SIGNATURE;
        round->head=round->buffer;
        round->tail=round->buffer;
        round->begin=round->buffer;
        round->end=&round->buffer[sizeof(round->buffer)-1];
}

/**   read the user_defined value from the ring_buffer,
 **    if no value available 0 is returned, on error -1 is
 **    returned, on success 1 is returned **/

int ring_buf_read(ring_buf *round,int *val)
{
        int* tmp=round->tail;

        if(round->signature !=R_SIGNATURE){
                printk("ring_buf_read:signature fake\n");
                return(-1);
        }

        if((tmp<round->begin)||(tmp>round->end)){
                printk("ring_buf_read:tail bad\n");
                return(-1);
        }

        if(tmp==round->head){
              return(0);
        }

        *val=*tmp++;

        if(tmp>round->end)
                tmp=round->begin;
        round->tail=tmp;
        if(tag){
                round->head=psudo_head;
                tag=0;
        }

        return(1);
}
/*
*
*/
int ring_buf_write(ring_buf *round,int val)
{
        int* tmp=round->head;

        if(round->signature !=R_SIGNATURE){
        	                printk("ring_buf_write:signature fake\n");
                return(-1);
        }
        if((tmp<round->begin)||(tmp>round->end)){
                printk("ring_buf_write:head bad\n");
                return(-1);
        }

        if(tag)
                return 0;
        (*tmp)=val;
        tmp++;

        if(tmp>round->end)
                tmp = round->begin;

        if(tmp==round->tail){
                tag=1;
                psudo_head=tmp;
                return(1);
        }
        round->head=tmp;
        return(1);
}

