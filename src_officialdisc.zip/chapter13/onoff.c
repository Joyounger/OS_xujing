#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <linux/ioport.h>
#include "trlight.h"
#include <asm/io.h>
int value=0;
void main (int argc, char** argv)
{
        int fd;
	if (argc<2){
		printf("usage: onoff [1/0]\n");
		exit(0);
	}
        fd=open("/dev/trlight",0);
	sscanf(argv[1],"%d",&value);
	printf("%d",value);
	if (value==1)
		value=TRLIGHT_START;
	else if (value==0)
		value=TRLIGHT_STOP;
        ioctl(fd,value,0);
	close(fd);
	
	
}
					
