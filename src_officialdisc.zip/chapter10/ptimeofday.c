#include <linux/time.h>
extern struct timezone sys_tz;

asmlinkage int sys_ptimeofday(struct timeval *tv, struct timezone *tz)
{
  if (tv) {
     struct timeval ktv;
     do_gettimeofday(&ktv);
     if (copy_to_user(tv, &ktv, sizeof(ktv)))
       return -EFAULT;
       printk("Date:%09d%09d", ktv.tv_sec, ktv.tv_usec);
   }
   if (tz) {
     if (copy_to_user(tz, &sys_tz, sizeof(sys_tz)))
       return -EFAULT;
      printk("The time is: %09d%09d",sys_tz.tz_minuteswest,sys_tz.tz_dsttime);
   }
   return 0;
}
