#include <linux/unistd.h>

#include <sys/time.h>
#define __NR_ptimeofday         239

int ptimeofday(struct timeval *tv, struct timezone *tz);
_syscall2(int, ptimeofday,struct timeval*,tv,struct timezone*,tz)

main()
{
        struct timeval tv;
        struct timezone tz;
        ptimeofday(&tv,&tz);
	printf("sec=%ld sec=%ld WG=%d corr=%d\n",tv.tv_sec,tv.tv_usec,tz.tz_minuteswest,tz.tz_dsttime);
	printf("time: %s\n", ctime(&(tv.tv_sec)));
}
